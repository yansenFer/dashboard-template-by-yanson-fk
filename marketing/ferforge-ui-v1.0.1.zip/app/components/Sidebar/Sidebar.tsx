import { ChevronLeft, ChevronDown, X } from "lucide-react";
import SidebarItem from "./SidebarItem";
import { useState } from "react";
import { Link, useLocation } from "react-router";
import { sidebarList } from "~/constants/sidebarList";
import { useSelector, useDispatch } from "react-redux";
import type { RootState } from "~/store/store";
import { motion, AnimatePresence } from "framer-motion";
import { closeMobileSidebar } from "~/store/features/sidebar/sidebarSlice";

const LogoIcon = ({ isDark }: { isDark: boolean }) => (
  <svg
    className={`w-7 h-7 shrink-0 ${isDark ? "text-slate-100" : "text-slate-800"}`}
    viewBox="0 0 32 32"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    {/* Arch / F outline */}
    <path
      d="M8 24V16C8 11.5817 11.5817 8 16 8C20.4183 8 24 11.5817 24 16V24"
      stroke="currentColor"
      strokeWidth="2.5"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    {/* Mid bar */}
    <path
      d="M8 17H24"
      stroke="currentColor"
      strokeWidth="2.5"
      strokeLinecap="round"
    />
    {/* Diagonal slash */}
    <path
      d="M9 26L23 6"
      stroke="currentColor"
      strokeWidth="3.2"
      strokeLinecap="round"
    />
  </svg>
);

export default function Sidebar() {
  const [collapsed, setCollapsed] = useState(false);
  const [expandedSections, setExpandedSections] = useState<string[]>(
    sidebarList.map((item) => item.titleMenu),
  );
  const location = useLocation();
  const isDark = useSelector((state: RootState) => state.dark.isDark);
  const isMobileOpen = useSelector(
    (state: RootState) => state.sidebar.isMobileOpen,
  );
  const dispatch = useDispatch();
  const pathname = location.pathname;

  const toggleSection = (title: string) => {
    if (collapsed) return;
    setExpandedSections((prev) =>
      prev.includes(title) ? prev.filter((t) => t !== title) : [...prev, title],
    );
  };

  const sidebarContent = (isMobile = false) => (
    <>
      {/* Header / Logo */}
      <div className="flex items-center justify-between px-3 py-4">
        <Link
          to={{ pathname: "/" }}
          className="flex items-center gap-2 w-full rounded-md px-2"
          onClick={() => isMobile && dispatch(closeMobileSidebar())}
        >
          {collapsed && !isMobile ? (
            <div className="w-full flex items-center justify-center py-2">
              <LogoIcon isDark={isDark} />
            </div>
          ) : (
            <div className="flex items-center gap-3 py-1 pl-1">
              <LogoIcon isDark={isDark} />
              <span
                className={[
                  "font-semibold text-lg tracking-wider font-sans uppercase",
                  isDark ? "text-slate-100" : "text-slate-800",
                ].join(" ")}
              >
                Ferforge UI
              </span>
            </div>
          )}
        </Link>

        {isMobile ? (
          /* Close button for mobile */
          <button
            type="button"
            onClick={() => dispatch(closeMobileSidebar())}
            className={`inline-flex size-8 cursor-pointer rounded-full items-center justify-center border shrink-0 ${isDark ? "bg-dark border-slate-700" : "bg-white border-slate-200"}`}
            aria-label="Close sidebar"
          >
            <X className="size-4" color={isDark ? "white" : "black"} />
          </button>
        ) : (
          <div className="flex items-center gap-2 relative">
            <button
              type="button"
              onClick={() => setCollapsed((v) => !v)}
              className={`inline-flex size-8 cursor-pointer rounded-full absolute -left-1 z-50 items-center justify-center border ${isDark ? "bg-dark border-dark" : "bg-white border-slate-200"}`}
              aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
              title={collapsed ? "Expand" : "Collapse"}
              aria-live="polite"
            >
              <ChevronLeft
                className={[
                  "size-4 transition-transform duration-300 ease-in-out",
                  collapsed ? "rotate-180" : "rotate-0",
                ].join(" ")}
                color={isDark ? "white" : "black"}
              />
            </button>
          </div>
        )}
      </div>

      {/* Navigation */}
      <nav
        className={`px-2 pb-4 flex-1 relative z-10 ${collapsed && !isMobile ? "overflow-y-visible" : "overflow-y-auto"} premium-scrollbar`}
        role="navigation"
        aria-label="Main navigation"
      >
        {collapsed && !isMobile ? (
          <div className="flex flex-col gap-1">
            {sidebarList
              .flatMap((parent) => parent.menu)
              .map((menu) => (
                <SidebarItem
                  key={menu.href}
                  href={menu.href}
                  icon={menu.icon}
                  label={menu.label}
                  active={pathname === menu.href}
                  collapsed={collapsed}
                />
              ))}
          </div>
        ) : (
          sidebarList.map((parent) => {
            const isExpanded = expandedSections.includes(parent.titleMenu);
            return (
              <div
                className="px-4 mb-1 transition-all duration-300"
                key={parent.titleMenu}
              >
                <button
                  onClick={() => toggleSection(parent.titleMenu)}
                  className="w-full flex items-center justify-between mb-1 group cursor-pointer"
                >
                  <p
                    className={`transition-all duration-300 text-base font-bold origin-left ease-in-out ${isDark ? "text-white" : "text-[var(--muted-foreground)]"}`}
                  >
                    {parent.titleMenu}
                  </p>
                  <ChevronDown
                    className={`size-3 transition-transform duration-300 ${isDark ? "text-gray-400" : "text-gray-500"} ${isExpanded ? "rotate-180" : "rotate-0"}`}
                  />
                </button>

                <AnimatePresence initial={false}>
                  {isExpanded && (
                    <motion.div
                      initial="collapsed"
                      animate="expanded"
                      exit="collapsed"
                      variants={{
                        expanded: { opacity: 1, height: "auto", marginTop: 0 },
                        collapsed: { opacity: 0, height: 0, marginTop: 0 },
                      }}
                      transition={{
                        duration: 0.3,
                        ease: [0.04, 0.62, 0.23, 0.98],
                      }}
                      className="overflow-hidden"
                    >
                      <ul className="mb-2 space-y-0.5">
                        {parent.menu.map((menu) => (
                          <li key={menu.href}>
                            <SidebarItem
                              href={menu.href}
                              icon={menu.icon}
                              label={menu.label}
                              active={pathname === menu.href}
                              collapsed={false}
                              onNavigate={
                                isMobile
                                  ? () => dispatch(closeMobileSidebar())
                                  : undefined
                              }
                            />
                          </li>
                        ))}
                      </ul>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })
        )}
      </nav>
    </>
  );

  return (
    <>
      {/* Desktop Sidebar */}
      <aside
        className={[
          "sidebar-scroll-container hidden md:flex md:flex-col md:shrink-0 h-screen transition-all duration-300",
          `${isDark ? "bg-dark text-white border-transparent" : "bg-white text-black border-slate-200"} border-r text-[var(--color-sidebar-foreground)]`,
          "will-change-[width]",
          collapsed ? "w-20 -ml-2" : "w-64",
        ].join(" ")}
        aria-label="Primary"
        data-collapsed={collapsed}
      >
        {sidebarContent(false)}
      </aside>

      {/* Mobile Sidebar Drawer */}
      <AnimatePresence>
        {isMobileOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              key="mobile-backdrop"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="fixed inset-0 z-40 bg-black/50 md:hidden"
              onClick={() => dispatch(closeMobileSidebar())}
              aria-hidden="true"
            />
            {/* Drawer */}
            <motion.aside
              key="mobile-sidebar"
              initial={{ x: "-100%" }}
              animate={{ x: 0 }}
              exit={{ x: "-100%" }}
              transition={{ duration: 0.25, ease: "easeInOut" }}
              className={[
                "fixed inset-y-0 left-0 z-50 flex flex-col w-72 h-screen md:hidden",
                isDark
                  ? "bg-dark text-white border-transparent"
                  : "bg-white text-black border-slate-200",
                "border-r shadow-2xl",
              ].join(" ")}
              aria-label="Mobile navigation"
            >
              {sidebarContent(true)}
            </motion.aside>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
